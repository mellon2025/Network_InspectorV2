# Network Inspector V2 — HyperSoft

A comprehensive Android network analysis tool built with Clean Architecture + MVVM.

## Features
- **Network Scanner** — discover all devices on your local network
- **Ping** — measure latency with packet loss statistics
- **Port Scanner** — scan common/custom ports with service detection
- **DNS Lookup** — A, AAAA, MX, NS, TXT, PTR records
- **Traceroute** — visual hop-by-hop path tracing
- **WHOIS** — domain registration & ownership info
- **SSL Inspector** — certificate details, expiry, cipher info
- **Speed Test** — download/upload speed via Cloudflare
- **Export** — PDF, JSON, CSV reports

## Tech Stack
- **Language:** Kotlin 1.9
- **Architecture:** Clean Architecture + MVVM
- **DI:** Hilt
- **DB:** Room
- **Async:** Coroutines + Flow
- **Networking:** OkHttp + Retrofit
- **UI:** Material 3, ViewBinding, Navigation Component

## Requirements
- Android Studio Hedgehog (2023.1.1) or later
- Android SDK 34
- Java / JDK 17

## Build Steps
1. Open project in Android Studio
2. Let Gradle sync complete (it will download Gradle 8.4 automatically via the wrapper)
3. Set `sdk.dir` in `local.properties` if not already detected
4. Click **Run** or `./gradlew assembleDebug`

## Font Note
Place `Inter-Regular.ttf`, `Inter-Medium.ttf`, `Inter-SemiBold.ttf`, `Inter-Bold.ttf`
in `app/src/main/res/font/` (download free from fonts.google.com).

## Package
`com.hypersoft.networkinspector`

## Developer
HyperSoft — https://hyper-soft--aalylaarqy10.replit.app/

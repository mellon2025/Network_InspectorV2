# Add project specific ProGuard rules here.

# Kotlin
-keep class kotlin.** { *; }
-keep class kotlinx.coroutines.** { *; }

# Hilt / Dagger
-keepclasseswithmembernames class * { @dagger.* <fields>; }
-keep class * extends dagger.hilt.android.internal.managers.* { *; }

# Room
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keepclassmembers @androidx.room.Entity class * { *; }

# Gson
-keep class com.google.gson.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.stream.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# Retrofit
-keep class retrofit2.** { *; }
-keepattributes Exceptions

# iText PDF
-dontwarn com.itextpdf.**
-keep class com.itextpdf.** { *; }

# OpenCSV
-keep class com.opencsv.** { *; }

# MPAndroidChart
-keep class com.github.mikephil.charting.** { *; }

# Domain models (keep for Gson serialization)
-keep class com.hypersoft.networkinspector.domain.model.** { *; }

# Keep all Fragments
-keep class com.hypersoft.networkinspector.presentation.ui.** extends androidx.fragment.app.Fragment { *; }

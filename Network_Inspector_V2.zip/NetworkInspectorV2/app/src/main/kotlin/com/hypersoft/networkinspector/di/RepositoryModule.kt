package com.hypersoft.networkinspector.di
import com.hypersoft.networkinspector.data.repository.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.Binds; import dagger.Module; import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent; import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds @Singleton abstract fun bindNetworkScan(i: NetworkScanRepositoryImpl): NetworkScanRepository
    @Binds @Singleton abstract fun bindPing(i: PingRepositoryImpl): PingRepository
    @Binds @Singleton abstract fun bindPortScan(i: PortScanRepositoryImpl): PortScanRepository
    @Binds @Singleton abstract fun bindDns(i: DnsRepositoryImpl): DnsRepository
    @Binds @Singleton abstract fun bindTraceroute(i: TracerouteRepositoryImpl): TracerouteRepository
    @Binds @Singleton abstract fun bindWhois(i: WhoisRepositoryImpl): WhoisRepository
    @Binds @Singleton abstract fun bindSsl(i: SslRepositoryImpl): SslRepository
    @Binds @Singleton abstract fun bindHttpHeader(i: HttpHeaderRepositoryImpl): HttpHeaderRepository
    @Binds @Singleton abstract fun bindSpeedTest(i: SpeedTestRepositoryImpl): SpeedTestRepository
    @Binds @Singleton abstract fun bindNetworkInfo(i: NetworkInfoRepositoryImpl): NetworkInfoRepository
    @Binds @Singleton abstract fun bindHistory(i: ScanHistoryRepositoryImpl): ScanHistoryRepository
}

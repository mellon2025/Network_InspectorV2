package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.ScanRecord
import kotlinx.coroutines.flow.Flow
interface ScanHistoryRepository {
    fun getAllScans(): Flow<List<ScanRecord>>
    suspend fun saveScan(record: ScanRecord): Long
    suspend fun deleteScan(id: Long)
    suspend fun clearAllScans()
}

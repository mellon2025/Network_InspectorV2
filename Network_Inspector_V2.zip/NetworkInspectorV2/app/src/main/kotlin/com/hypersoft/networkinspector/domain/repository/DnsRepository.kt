package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.DnsQueryType
import com.hypersoft.networkinspector.domain.model.DnsResult
interface DnsRepository {
    suspend fun lookup(domain: String, type: DnsQueryType): DnsResult
    suspend fun reverseLookup(ip: String): DnsResult
}

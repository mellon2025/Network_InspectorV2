package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.google.gson.Gson; import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job; import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class PingViewModel @Inject constructor(
    private val repo: PingRepository, private val history: ScanHistoryRepository, private val gson: Gson
) : ViewModel() {
    private val _result = MutableStateFlow<PingResult?>(null); val result = _result.asStateFlow()
    private val _running = MutableStateFlow(false); val isRunning = _running.asStateFlow()
    private var job: Job? = null
    fun startPing(host:String, count:Int=8) {
        if(_running.value) return; _result.value=null; _running.value=true
        job = viewModelScope.launch {
            val t0=System.currentTimeMillis()
            repo.ping(host,count).catch{_running.value=false}.onCompletion{_running.value=false}.collect{ r->
                _result.value=r
                if(r.sentPackets==count){
                    history.saveScan(ScanRecord(scanType="Ping",target=host,
                        resultSummary="Avg:${String.format("%.1f",r.avgRtt)}ms Loss:${String.format("%.0f",r.packetLossPercent)}%",
                        resultJson=gson.toJson(r),isSuccess=r.isSuccess,durationMs=System.currentTimeMillis()-t0))
                }
            }
        }
    }
    fun stop() { job?.cancel(); _running.value=false }
}

package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.NetworkInfo
import kotlinx.coroutines.flow.Flow
interface NetworkInfoRepository {
    fun getNetworkInfo(): Flow<NetworkInfo>
    suspend fun getPublicIp(): String
}

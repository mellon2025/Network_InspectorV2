package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val networkInfoRepo: NetworkInfoRepository,
    private val historyRepo: ScanHistoryRepository
) : ViewModel() {
    private val _networkInfo = MutableStateFlow<NetworkInfo?>(null)
    val networkInfo: StateFlow<NetworkInfo?> = _networkInfo.asStateFlow()
    private val _publicIp = MutableStateFlow("Fetching…")
    val publicIp: StateFlow<String> = _publicIp.asStateFlow()
    val recentScans: StateFlow<List<ScanRecord>> = historyRepo.getAllScans()
        .map { it.take(5) }.catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    init {
        viewModelScope.launch { networkInfoRepo.getNetworkInfo().catch { emit(NetworkInfo()) }.collect { _networkInfo.value = it } }
        viewModelScope.launch { _publicIp.value = networkInfoRepo.getPublicIp().ifEmpty { "Unavailable" } }
    }
    fun refresh() { viewModelScope.launch { _publicIp.value = networkInfoRepo.getPublicIp().ifEmpty { "Unavailable" } } }
}

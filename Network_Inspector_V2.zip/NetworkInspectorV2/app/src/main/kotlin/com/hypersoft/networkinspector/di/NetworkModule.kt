package com.hypersoft.networkinspector.di
import com.google.gson.Gson; import com.google.gson.GsonBuilder
import dagger.Module; import dagger.Provides; import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient; import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit; import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides @Singleton
    fun provideOkHttp(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
        .build()
    @Provides @Singleton fun provideGson(): Gson = GsonBuilder().create()
}

package com.hypersoft.networkinspector.presentation.ui.onboarding
import android.view.LayoutInflater; import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hypersoft.networkinspector.databinding.ItemOnboardingPageBinding
class OnboardingAdapter(private val pages: List<OnboardingPage>) : RecyclerView.Adapter<OnboardingAdapter.VH>() {
    inner class VH(val b: ItemOnboardingPageBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(p: OnboardingPage) { b.tvTitle.text=p.title; b.tvDescription.text=p.description; b.ivIllustration.setImageResource(p.imageRes) }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int) = VH(ItemOnboardingPageBinding.inflate(LayoutInflater.from(p.context),p,false))
    override fun onBindViewHolder(h:VH,pos:Int) = h.bind(pages[pos])
    override fun getItemCount() = pages.size
}

package com.hypersoft.networkinspector.presentation.adapter
import android.view.*; import androidx.recyclerview.widget.*
import com.hypersoft.networkinspector.databinding.ItemNetworkDeviceBinding
import com.hypersoft.networkinspector.domain.model.NetworkDevice
class DeviceAdapter : ListAdapter<NetworkDevice,DeviceAdapter.VH>(DIFF) {
    companion object { val DIFF = object:DiffUtil.ItemCallback<NetworkDevice>(){
        override fun areItemsTheSame(a:NetworkDevice,b:NetworkDevice) = a.ip==b.ip
        override fun areContentsTheSame(a:NetworkDevice,b:NetworkDevice) = a==b
    }}
    inner class VH(val b:ItemNetworkDeviceBinding):RecyclerView.ViewHolder(b.root) {
        fun bind(d:NetworkDevice){
            b.tvIp.text=d.ip; b.tvHostname.text=d.hostname.ifEmpty{d.ip}
            b.tvVendor.text=d.vendor; b.tvDeviceType.text=d.deviceType.label
            b.tvPing.text=if(d.responseTime>=0) "${d.responseTime}ms" else "—"
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int)=VH(ItemNetworkDeviceBinding.inflate(LayoutInflater.from(p.context),p,false))
    override fun onBindViewHolder(h:VH,pos:Int)=h.bind(getItem(pos))
}

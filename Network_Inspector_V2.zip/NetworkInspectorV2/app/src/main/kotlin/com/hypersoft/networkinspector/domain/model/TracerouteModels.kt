package com.hypersoft.networkinspector.domain.model

data class TracerouteHop(
    val hopNumber: Int = 0,
    val ip: String = "",
    val hostname: String = "",
    val rtt1: Double = -1.0,
    val rtt2: Double = -1.0,
    val rtt3: Double = -1.0,
    val isTimeout: Boolean = false
)

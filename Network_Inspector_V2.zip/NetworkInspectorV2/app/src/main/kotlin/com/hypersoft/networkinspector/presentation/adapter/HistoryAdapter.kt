package com.hypersoft.networkinspector.presentation.adapter
import android.view.*; import androidx.recyclerview.widget.*
import com.hypersoft.networkinspector.databinding.ItemHistoryBinding
import com.hypersoft.networkinspector.domain.model.ScanRecord
import java.text.SimpleDateFormat; import java.util.*
class HistoryAdapter(private val onDelete:(Long)->Unit) : ListAdapter<ScanRecord,HistoryAdapter.VH>(DIFF) {
    companion object { val DIFF=object:DiffUtil.ItemCallback<ScanRecord>(){
        override fun areItemsTheSame(a:ScanRecord,b:ScanRecord)=a.id==b.id
        override fun areContentsTheSame(a:ScanRecord,b:ScanRecord)=a==b
    }}
    private val fmt=SimpleDateFormat("MMM dd · HH:mm",Locale.getDefault())
    inner class VH(val b:ItemHistoryBinding):RecyclerView.ViewHolder(b.root) {
        fun bind(r:ScanRecord){
            b.tvType.text=r.scanType; b.tvTarget.text=r.target
            b.tvSummary.text=r.resultSummary; b.tvTime.text=fmt.format(Date(r.timestamp))
            b.btnDelete.setOnClickListener{onDelete(r.id)}
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int)=VH(ItemHistoryBinding.inflate(LayoutInflater.from(p.context),p,false))
    override fun onBindViewHolder(h:VH,pos:Int)=h.bind(getItem(pos))
}

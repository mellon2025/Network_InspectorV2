package com.hypersoft.networkinspector.presentation.ui.onboarding
import android.content.Context; import android.content.Intent; import android.os.Bundle; import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.hypersoft.networkinspector.R
import com.hypersoft.networkinspector.databinding.ActivityOnboardingBinding
import com.hypersoft.networkinspector.presentation.ui.main.MainActivity
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class OnboardingActivity : AppCompatActivity() {
    private lateinit var b: ActivityOnboardingBinding
    private val pages = listOf(
        OnboardingPage("Network Scanner","Discover every device on your local network with full details",R.drawable.ic_network_scan),
        OnboardingPage("10+ Network Tools","Ping, Traceroute, Port Scanner, DNS, WHOIS, SSL Inspector & more",R.drawable.ic_tools),
        OnboardingPage("Export Reports","Save & share results as PDF, JSON, or CSV instantly",R.drawable.ic_report)
    )
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); b = ActivityOnboardingBinding.inflate(layoutInflater); setContentView(b.root)
        val adapter = OnboardingAdapter(pages); b.viewPager.adapter = adapter
        b.dotsIndicator.attachTo(b.viewPager)
        b.btnSkip.setOnClickListener { finish_() }
        b.btnNext.setOnClickListener {
            val c = b.viewPager.currentItem
            if (c < pages.size-1) b.viewPager.currentItem = c+1 else finish_()
        }
    }
    private fun finish_() {
        getSharedPreferences("hs_prefs", Context.MODE_PRIVATE).edit().putBoolean("onboarding_done",true).apply()
        startActivity(Intent(this, MainActivity::class.java)); finish()
    }
}
data class OnboardingPage(val title: String, val description: String, val imageRes: Int)

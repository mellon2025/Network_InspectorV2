package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.google.gson.Gson; import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job; import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class TracerouteViewModel @Inject constructor(
    private val repo: TracerouteRepository, private val history: ScanHistoryRepository, private val gson: Gson
) : ViewModel() {
    private val _hops = MutableStateFlow<List<TracerouteHop>>(emptyList()); val hops = _hops.asStateFlow()
    private val _running = MutableStateFlow(false); val isRunning = _running.asStateFlow()
    private var job: Job? = null
    fun trace(host:String, maxHops:Int=30) {
        if(_running.value) return; _hops.value=emptyList(); _running.value=true
        job = viewModelScope.launch {
            val t0=System.currentTimeMillis()
            repo.traceroute(host,maxHops).catch{_running.value=false}.onCompletion{
                _running.value=false
                history.saveScan(ScanRecord(scanType="Traceroute",target=host,
                    resultSummary="${_hops.value.size} hops",resultJson=gson.toJson(_hops.value),
                    isSuccess=_hops.value.isNotEmpty(),durationMs=System.currentTimeMillis()-t0))
            }.collect{ _hops.value=_hops.value+it }
        }
    }
    fun stop() { job?.cancel(); _running.value=false }
}

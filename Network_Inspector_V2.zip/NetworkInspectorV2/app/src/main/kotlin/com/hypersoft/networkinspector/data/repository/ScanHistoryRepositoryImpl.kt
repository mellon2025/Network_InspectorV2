package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.data.local.dao.ScanRecordDao
import com.hypersoft.networkinspector.data.local.entity.ScanRecordEntity
import com.hypersoft.networkinspector.domain.model.ScanRecord
import com.hypersoft.networkinspector.domain.repository.ScanHistoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScanHistoryRepositoryImpl @Inject constructor(
    private val dao: ScanRecordDao
) : ScanHistoryRepository {
    override fun getAllScans() = dao.getAllScans().map { it.map(ScanRecordEntity::toDomain) }
    override suspend fun saveScan(record: ScanRecord) = dao.insert(record.toEntity())
    override suspend fun deleteScan(id: Long) = dao.deleteById(id)
    override suspend fun clearAllScans() = dao.deleteAll()
}

fun ScanRecordEntity.toDomain() = ScanRecord(id, scanType, target, resultSummary, resultJson, isSuccess, durationMs, timestamp)
fun ScanRecord.toEntity() = ScanRecordEntity(id, scanType, target, resultSummary, resultJson, isSuccess, durationMs, timestamp)

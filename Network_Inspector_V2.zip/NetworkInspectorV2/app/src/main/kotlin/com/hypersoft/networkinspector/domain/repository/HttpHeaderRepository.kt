package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.HttpHeaderResult
interface HttpHeaderRepository {
    suspend fun inspect(url: String): HttpHeaderResult
}

package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.google.gson.Gson; import com.hypersoft.networkinspector.data.util.NetworkUtils
import com.hypersoft.networkinspector.domain.model.*; import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job; import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class PortScanViewModel @Inject constructor(
    private val repo: PortScanRepository, private val history: ScanHistoryRepository, private val gson: Gson
) : ViewModel() {
    private val _results = MutableStateFlow<List<PortScanResult>>(emptyList()); val scanResults = _results.asStateFlow()
    private val _summary = MutableStateFlow<PortScanSummary?>(null); val summary = _summary.asStateFlow()
    private val _scanning = MutableStateFlow(false); val isScanning = _scanning.asStateFlow()
    private val _progress = MutableStateFlow(0); val progress = _progress.asStateFlow()
    private var job: Job? = null
    fun scanCommonPorts(host:String) {
        if(_scanning.value) return; _results.value=emptyList(); _summary.value=null
        _scanning.value=true; _progress.value=0
        job = viewModelScope.launch {
            val t0=System.currentTimeMillis(); val total=NetworkUtils.COMMON_PORTS.size; var n=0
            repo.scanPorts(host,NetworkUtils.COMMON_PORTS).catch{_scanning.value=false}.onCompletion{
                val open=_results.value.filter{it.isOpen}
                _summary.value=PortScanSummary(host,total,open,total-open.size,0,System.currentTimeMillis()-t0)
                _scanning.value=false
                _summary.value?.let{s->history.saveScan(ScanRecord(scanType="Port Scan",target=host,
                    resultSummary="${s.openPorts.size} open of ${s.totalScanned}",
                    resultJson=gson.toJson(s),isSuccess=true,durationMs=s.scanDuration))}
            }.collect{ r-> n++; _progress.value=n*100/total
                _results.value=(_results.value+r).sortedBy{it.port} }
        }
    }
    fun stop() { job?.cancel(); _scanning.value=false }
}

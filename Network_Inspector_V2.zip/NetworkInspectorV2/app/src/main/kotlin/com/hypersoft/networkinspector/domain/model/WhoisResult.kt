package com.hypersoft.networkinspector.domain.model

data class WhoisResult(
    val query: String = "",
    val domainName: String = "",
    val registrar: String = "",
    val registrationDate: String = "",
    val expirationDate: String = "",
    val updatedDate: String = "",
    val nameServers: List<String> = emptyList(),
    val status: List<String> = emptyList(),
    val registrantOrg: String = "",
    val registrantCountry: String = "",
    val rawData: String = "",
    val isSuccess: Boolean = false,
    val errorMessage: String = ""
)

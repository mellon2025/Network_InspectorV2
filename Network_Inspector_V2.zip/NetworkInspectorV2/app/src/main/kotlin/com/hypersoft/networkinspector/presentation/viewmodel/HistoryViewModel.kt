package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.hypersoft.networkinspector.domain.model.ScanRecord
import com.hypersoft.networkinspector.domain.repository.ScanHistoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class HistoryViewModel @Inject constructor(private val repo: ScanHistoryRepository) : ViewModel() {
    val scans: StateFlow<List<ScanRecord>> = repo.getAllScans().catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun delete(id:Long) = viewModelScope.launch { repo.deleteScan(id) }
    fun clearAll() = viewModelScope.launch { repo.clearAllScans() }
}

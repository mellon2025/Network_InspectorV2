package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.DnsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.net.InetAddress
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DnsRepositoryImpl @Inject constructor() : DnsRepository {

    override suspend fun lookup(domain: String, type: DnsQueryType): DnsResult =
        withContext(Dispatchers.IO) {
            val t0 = System.currentTimeMillis()
            try {
                val addrs = InetAddress.getAllByName(domain)
                val records = addrs.map { a ->
                    DnsRecord(domain, if (a.hostAddress?.contains(':') == true) "AAAA" else "A", 300, a.hostAddress ?: "")
                }
                DnsResult(domain, type, records, System.currentTimeMillis() - t0, records.isNotEmpty())
            } catch (e: Exception) {
                DnsResult(domain, type, emptyList(), System.currentTimeMillis() - t0, false, e.message ?: "Failed")
            }
        }

    override suspend fun reverseLookup(ip: String): DnsResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        try {
            val h = InetAddress.getByName(ip).canonicalHostName
            DnsResult(ip, DnsQueryType.PTR,
                listOf(DnsRecord(ip, "PTR", 300, h)),
                System.currentTimeMillis() - t0, h != ip)
        } catch (e: Exception) {
            DnsResult(ip, DnsQueryType.PTR, emptyList(), System.currentTimeMillis() - t0, false, e.message ?: "Failed")
        }
    }
}

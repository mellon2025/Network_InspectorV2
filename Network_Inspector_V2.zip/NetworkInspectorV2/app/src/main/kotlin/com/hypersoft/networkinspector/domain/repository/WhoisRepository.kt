package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.WhoisResult
interface WhoisRepository {
    suspend fun lookup(query: String): WhoisResult
}

package com.hypersoft.networkinspector.presentation.ui.about
import android.os.Bundle; import android.view.*
import androidx.fragment.app.Fragment
import com.hypersoft.networkinspector.R
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class AboutFragment : Fragment(R.layout.fragment_about) {
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?): View =
        i.inflate(R.layout.fragment_about,c,false)
}

package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.domain.model.WhoisResult
import com.hypersoft.networkinspector.domain.repository.WhoisRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.PrintWriter
import java.net.Socket
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WhoisRepositoryImpl @Inject constructor() : WhoisRepository {

    override suspend fun lookup(query: String): WhoisResult = withContext(Dispatchers.IO) {
        try {
            val raw = query("whois.iana.org", query)
            val ref = raw.lines().firstOrNull { it.lowercase().startsWith("refer:") }
                ?.substringAfter(":")?.trim() ?: ""
            val final = if (ref.isNotEmpty()) query(ref, query) else raw
            parse(query, if (final.isNotEmpty()) final else raw)
        } catch (e: Exception) {
            WhoisResult(query = query, isSuccess = false, errorMessage = e.message ?: "Failed")
        }
    }

    private fun query(server: String, q: String): String = try {
        Socket(server, 43).use { s ->
            s.soTimeout = 10000
            PrintWriter(s.getOutputStream(), true).println(q)
            s.getInputStream().bufferedReader().readText()
        }
    } catch (_: Exception) { "" }

    private fun parse(q: String, raw: String): WhoisResult {
        fun f(vararg keys: String) = keys.firstNotNullOfOrNull { k ->
            raw.lines().firstOrNull { it.lowercase().startsWith(k.lowercase()) }?.substringAfter(":")?.trim()
        } ?: ""
        fun fl(vararg keys: String) = keys.flatMap { k ->
            raw.lines().filter { it.lowercase().startsWith(k.lowercase()) }.map { it.substringAfter(":").trim() }
        }.distinct()
        return WhoisResult(
            query = q,
            domainName    = f("Domain Name:", "domain:"),
            registrar     = f("Registrar:", "registrar:"),
            registrationDate = f("Creation Date:", "created:"),
            expirationDate   = f("Registry Expiry Date:", "Expiry date:", "expires:"),
            updatedDate      = f("Updated Date:", "last-modified:"),
            nameServers      = fl("Name Server:", "nserver:"),
            status           = fl("Domain Status:", "status:"),
            registrantOrg    = f("Registrant Organization:", "org:"),
            registrantCountry= f("Registrant Country:", "country:"),
            rawData = raw, isSuccess = raw.isNotEmpty()
        )
    }
}

package com.hypersoft.networkinspector.presentation.ui.portscan
import android.os.Bundle; import android.view.*
import androidx.fragment.app.Fragment
import com.hypersoft.networkinspector.R
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class PortScanFragment : Fragment(R.layout.fragment_port_scan) {
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?): View =
        i.inflate(R.layout.fragment_port_scan,c,false)
}

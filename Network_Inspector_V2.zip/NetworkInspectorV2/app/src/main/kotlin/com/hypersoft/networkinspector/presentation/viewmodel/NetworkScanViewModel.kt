package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job; import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class NetworkScanViewModel @Inject constructor(
    private val repo: NetworkScanRepository,
    private val history: ScanHistoryRepository,
    private val gson: Gson
) : ViewModel() {
    sealed class ScanState { object Idle:ScanState(); object Scanning:ScanState()
        data class Complete(val n:Int):ScanState(); data class Error(val msg:String):ScanState() }
    private val _state   = MutableStateFlow<ScanState>(ScanState.Idle)
    val scanState: StateFlow<ScanState> = _state.asStateFlow()
    private val _devices = MutableStateFlow<List<NetworkDevice>>(emptyList())
    val devices: StateFlow<List<NetworkDevice>> = _devices.asStateFlow()
    private val _progress = MutableStateFlow(0)
    val progress: StateFlow<Int> = _progress.asStateFlow()
    private var job: Job? = null
    fun startScan() {
        if (_state.value is ScanState.Scanning) return
        _devices.value = emptyList(); _progress.value = 0; _state.value = ScanState.Scanning
        job = viewModelScope.launch {
            val t0 = System.currentTimeMillis(); var n = 0
            try {
                val subnet = repo.getSubnet()
                repo.scanLocalNetwork(subnet).catch { _state.value = ScanState.Error(it.message?:"Error") }
                    .collect { d -> n++; _progress.value = (n*100/254).coerceAtMost(99)
                        _devices.value = (_devices.value+d).sortedWith(compareBy({!it.isGateway},{ipLong(it.ip)})) }
                _progress.value = 100; _state.value = ScanState.Complete(_devices.value.size)
                history.saveScan(ScanRecord(scanType="Network Scan", target="$subnet.0/24",
                    resultSummary="${_devices.value.size} devices", resultJson=gson.toJson(_devices.value),
                    isSuccess=true, durationMs=System.currentTimeMillis()-t0))
            } catch (e:Exception) { _state.value = ScanState.Error(e.message?:"Unknown") }
        }
    }
    fun stopScan() { job?.cancel(); _state.value = ScanState.Idle }
    private fun ipLong(ip:String) = try { ip.split(".").fold(0L){a,p->a*256+(p.toLongOrNull()?:0)} } catch(_:Exception){0L}
}

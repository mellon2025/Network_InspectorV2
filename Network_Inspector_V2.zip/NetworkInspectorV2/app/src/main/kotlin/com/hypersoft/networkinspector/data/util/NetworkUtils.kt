package com.hypersoft.networkinspector.data.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import timber.log.Timber
import java.net.InetAddress
import java.net.NetworkInterface
import java.nio.ByteOrder

object NetworkUtils {

    fun getLocalIpAddress(context: Context): String {
        return try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ipInt = wm.connectionInfo.ipAddress
            if (ipInt == 0) getIpFromNetworkInterface() ?: "192.168.1.100"
            else {
                val ip = if (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) Integer.reverseBytes(ipInt) else ipInt
                InetAddress.getByAddress(byteArrayOf(
                    (ip shr 24 and 0xFF).toByte(), (ip shr 16 and 0xFF).toByte(),
                    (ip shr 8 and 0xFF).toByte(), (ip and 0xFF).toByte()
                )).hostAddress ?: "192.168.1.100"
            }
        } catch (e: Exception) { getIpFromNetworkInterface() ?: "192.168.1.100" }
    }

    private fun getIpFromNetworkInterface(): String? = try {
        NetworkInterface.getNetworkInterfaces()?.toList()
            ?.flatMap { it.inetAddresses.toList() }
            ?.firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains(':') == false }
            ?.hostAddress
    } catch (e: Exception) { null }

    fun getSubnetBase(ip: String): String {
        val p = ip.split(".")
        return if (p.size >= 3) "${p[0]}.${p[1]}.${p[2]}" else "192.168.1"
    }

    fun getGatewayIp(context: Context): String = try {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo.gateway
        val ip = if (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) Integer.reverseBytes(g) else g
        InetAddress.getByAddress(byteArrayOf(
            (ip shr 24 and 0xFF).toByte(), (ip shr 16 and 0xFF).toByte(),
            (ip shr 8 and 0xFF).toByte(), (ip and 0xFF).toByte()
        )).hostAddress ?: "192.168.1.1"
    } catch (e: Exception) { "192.168.1.1" }

    fun getMacAddress(): String = try {
        NetworkInterface.getNetworkInterfaces()?.toList()
            ?.firstOrNull { it.name.equals("wlan0", true) }
            ?.hardwareAddress?.joinToString(":") { "%02X".format(it) } ?: "02:00:00:00:00:00"
    } catch (e: Exception) { "02:00:00:00:00:00" }

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    fun intToIp(ip: Int): String =
        "${ip and 0xFF}.${ip shr 8 and 0xFF}.${ip shr 16 and 0xFF}.${ip shr 24 and 0xFF}"

    fun getServiceName(port: Int): String = when (port) {
        21 -> "FTP"; 22 -> "SSH"; 23 -> "Telnet"; 25 -> "SMTP"; 53 -> "DNS"
        80 -> "HTTP"; 110 -> "POP3"; 143 -> "IMAP"; 443 -> "HTTPS"; 445 -> "SMB"
        465 -> "SMTPS"; 587 -> "SMTP/TLS"; 993 -> "IMAPS"; 995 -> "POP3S"
        1433 -> "MSSQL"; 1521 -> "Oracle"; 3306 -> "MySQL"; 3389 -> "RDP"
        5432 -> "PostgreSQL"; 5900 -> "VNC"; 6379 -> "Redis"; 8080 -> "HTTP-Alt"
        8443 -> "HTTPS-Alt"; 27017 -> "MongoDB"; else -> ""
    }

    val COMMON_PORTS = listOf(
        21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445,
        465, 587, 993, 995, 1433, 1521, 3306, 3389, 5432, 5900,
        6379, 8080, 8443, 27017
    )

    private val MAC_VENDORS = mapOf(
        "000C29" to "VMware", "001A2B" to "Cisco", "00265A" to "Apple",
        "3C5A37" to "Google", "B4E62D" to "Apple", "E8E0B7" to "TP-Link",
        "B0487A" to "TP-Link", "74D435" to "Samsung", "ACDE48" to "Apple"
    )

    fun getVendorFromMac(mac: String): String {
        if (mac == "Unknown") return "Unknown"
        val prefix = mac.replace(":", "").replace("-", "").take(6).uppercase()
        return MAC_VENDORS[prefix] ?: "Unknown"
    }
}

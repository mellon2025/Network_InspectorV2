package com.hypersoft.networkinspector.domain.model

data class ScanRecord(
    val id: Long = 0,
    val scanType: String = "",
    val target: String = "",
    val resultSummary: String = "",
    val resultJson: String = "",
    val isSuccess: Boolean = false,
    val durationMs: Long = 0L,
    val timestamp: Long = System.currentTimeMillis()
)

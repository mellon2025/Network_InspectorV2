package com.hypersoft.networkinspector.presentation.ui.speedtest
import android.os.Bundle; import android.view.*
import androidx.fragment.app.Fragment
import com.hypersoft.networkinspector.R
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class SpeedTestFragment : Fragment(R.layout.fragment_speed_test) {
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?): View =
        i.inflate(R.layout.fragment_speed_test,c,false)
}

package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.NetworkDevice
import kotlinx.coroutines.flow.Flow
interface NetworkScanRepository {
    fun scanLocalNetwork(subnet: String, timeout: Int = 500): Flow<NetworkDevice>
    suspend fun getGatewayIp(): String
    suspend fun getLocalIp(): String
    suspend fun getSubnet(): String
}

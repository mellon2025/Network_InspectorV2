package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.google.gson.Gson; import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class WhoisViewModel @Inject constructor(
    private val repo: WhoisRepository, private val history: ScanHistoryRepository, private val gson: Gson
) : ViewModel() {
    private val _result = MutableStateFlow<WhoisResult?>(null); val result = _result.asStateFlow()
    private val _loading = MutableStateFlow(false); val isLoading = _loading.asStateFlow()
    fun lookup(q:String) = viewModelScope.launch {
        _loading.value=true; _result.value=null; val t0=System.currentTimeMillis()
        val r=repo.lookup(q); _result.value=r; _loading.value=false
        history.saveScan(ScanRecord(scanType="WHOIS",target=q,
            resultSummary=if(r.isSuccess)"Registrar: ${r.registrar}" else r.errorMessage,
            resultJson=gson.toJson(r),isSuccess=r.isSuccess,durationMs=System.currentTimeMillis()-t0))
    }
}

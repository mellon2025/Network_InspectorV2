package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.google.gson.Gson; import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job; import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class SpeedTestViewModel @Inject constructor(
    private val repo: SpeedTestRepository, private val history: ScanHistoryRepository, private val gson: Gson
) : ViewModel() {
    private val _progress = MutableStateFlow<SpeedTestProgress?>(null); val progress = _progress.asStateFlow()
    private val _final = MutableStateFlow<SpeedTestResult?>(null); val finalResult = _final.asStateFlow()
    private val _running = MutableStateFlow(false); val isRunning = _running.asStateFlow()
    private var job: Job? = null
    fun startTest() {
        if(_running.value) return; _running.value=true; _final.value=null
        job = viewModelScope.launch {
            val t0=System.currentTimeMillis()
            repo.runSpeedTest().catch{_running.value=false}.collect{ p->
                _progress.value=p
                if(p.phase==SpeedTestPhase.COMPLETE && p.finalResult!=null){
                    _final.value=p.finalResult; _running.value=false
                    history.saveScan(ScanRecord(scanType="Speed Test",target="Cloudflare",
                        resultSummary="↓${String.format("%.1f",p.finalResult.downloadSpeedMbps)} ↑${String.format("%.1f",p.finalResult.uploadSpeedMbps)} Mbps",
                        resultJson=gson.toJson(p.finalResult),isSuccess=true,durationMs=System.currentTimeMillis()-t0))
                } else if(p.phase==SpeedTestPhase.ERROR){ _running.value=false }
            }
        }
    }
    fun stop() { job?.cancel(); _running.value=false }
}

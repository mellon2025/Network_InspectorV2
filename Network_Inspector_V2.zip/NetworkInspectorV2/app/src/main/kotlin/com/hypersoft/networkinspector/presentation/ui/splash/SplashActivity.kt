package com.hypersoft.networkinspector.presentation.ui.splash
import android.annotation.SuppressLint; import android.content.Context; import android.content.Intent; import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity; import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import com.hypersoft.networkinspector.databinding.ActivitySplashBinding
import com.hypersoft.networkinspector.presentation.ui.main.MainActivity
import com.hypersoft.networkinspector.presentation.ui.onboarding.OnboardingActivity
import dagger.hilt.android.AndroidEntryPoint; import kotlinx.coroutines.delay; import kotlinx.coroutines.launch
@SuppressLint("CustomSplashScreen") @AndroidEntryPoint
class SplashActivity : AppCompatActivity() {
    private lateinit var b: ActivitySplashBinding
    override fun onCreate(s: Bundle?) {
        installSplashScreen(); super.onCreate(s)
        b = ActivitySplashBinding.inflate(layoutInflater); setContentView(b.root)
        lifecycleScope.launch { delay(2200); navigate() }
    }
    private fun navigate() {
        val done = getSharedPreferences("hs_prefs", Context.MODE_PRIVATE).getBoolean("onboarding_done",false)
        startActivity(Intent(this, if(done) MainActivity::class.java else OnboardingActivity::class.java))
        finish(); overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}

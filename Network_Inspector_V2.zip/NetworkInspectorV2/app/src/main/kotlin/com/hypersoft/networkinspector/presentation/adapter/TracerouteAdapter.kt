package com.hypersoft.networkinspector.presentation.adapter
import android.view.*; import androidx.recyclerview.widget.*
import com.hypersoft.networkinspector.databinding.ItemTracerouteHopBinding
import com.hypersoft.networkinspector.domain.model.TracerouteHop
class TracerouteAdapter : ListAdapter<TracerouteHop,TracerouteAdapter.VH>(DIFF) {
    companion object { val DIFF=object:DiffUtil.ItemCallback<TracerouteHop>(){
        override fun areItemsTheSame(a:TracerouteHop,b:TracerouteHop)=a.hopNumber==b.hopNumber
        override fun areContentsTheSame(a:TracerouteHop,b:TracerouteHop)=a==b
    }}
    inner class VH(val b:ItemTracerouteHopBinding):RecyclerView.ViewHolder(b.root) {
        fun bind(h:TracerouteHop){
            b.tvHopNum.text="${h.hopNumber}"
            b.tvIp.text=if(h.isTimeout)"* * *" else h.ip
            b.tvRtt.text=if(h.isTimeout)"Timeout" else "${String.format("%.1f",h.rtt1)} ms"
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int)=VH(ItemTracerouteHopBinding.inflate(LayoutInflater.from(p.context),p,false))
    override fun onBindViewHolder(h:VH,pos:Int)=h.bind(getItem(pos))
}

package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.domain.model.PingResult
import com.hypersoft.networkinspector.domain.repository.PingRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.net.InetAddress
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

@Singleton
class PingRepositoryImpl @Inject constructor() : PingRepository {

    override fun ping(host: String, count: Int, timeout: Int): Flow<PingResult> = flow {
        val rtts = mutableListOf<Double>()
        var sent = 0; var received = 0; var resolvedIp = ""
        try {
            resolvedIp = InetAddress.getByName(host).hostAddress ?: host
        } catch (e: Exception) {
            emit(PingResult(host = host, isSuccess = false, errorMessage = "Cannot resolve: ${e.message}"))
            return@flow
        }
        repeat(count) { i ->
            sent++
            try {
                val start = System.currentTimeMillis()
                val ok = InetAddress.getByName(host).isReachable(timeout)
                val rtt = (System.currentTimeMillis() - start).toDouble()
                if (ok) { received++; rtts.add(rtt) }
                emit(PingResult(
                    host = host, ip = resolvedIp,
                    sentPackets = sent, receivedPackets = received, lostPackets = sent - received,
                    minRtt = if (rtts.isEmpty()) 0.0 else rtts.min(),
                    avgRtt = if (rtts.isEmpty()) 0.0 else rtts.average(),
                    maxRtt = if (rtts.isEmpty()) 0.0 else rtts.max(),
                    jitter = jitter(rtts),
                    packetLossPercent = (sent - received).toDouble() / sent * 100,
                    isSuccess = received > 0, roundTripTimes = rtts.toList()
                ))
            } catch (e: Exception) {
                emit(PingResult(host = host, ip = resolvedIp, sentPackets = sent,
                    receivedPackets = received, lostPackets = sent - received,
                    isSuccess = false, errorMessage = e.message ?: "Ping failed"))
            }
            if (i < count - 1) delay(1000)
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun quickPing(host: String, timeout: Int): Boolean = withContext(Dispatchers.IO) {
        try { InetAddress.getByName(host).isReachable(timeout) } catch (_: Exception) { false }
    }

    private fun jitter(rtts: List<Double>): Double {
        if (rtts.size < 2) return 0.0
        return rtts.zipWithNext { a, b -> abs(a - b) }.average()
    }
}

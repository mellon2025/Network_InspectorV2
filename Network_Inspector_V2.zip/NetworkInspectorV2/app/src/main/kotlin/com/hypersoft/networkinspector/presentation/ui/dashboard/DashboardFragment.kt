package com.hypersoft.networkinspector.presentation.ui.dashboard
import android.os.Bundle; import android.view.*; import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels; import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.hypersoft.networkinspector.R
import com.hypersoft.networkinspector.databinding.FragmentDashboardBinding
import com.hypersoft.networkinspector.presentation.viewmodel.DashboardViewModel
import dagger.hilt.android.AndroidEntryPoint; import kotlinx.coroutines.flow.collectLatest; import kotlinx.coroutines.launch
@AndroidEntryPoint
class DashboardFragment : Fragment(R.layout.fragment_dashboard) {
    private var _b: FragmentDashboardBinding? = null; private val b get() = _b!!
    private val vm: DashboardViewModel by viewModels()
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) = FragmentDashboardBinding.inflate(i,c,false).also{_b=it}.root
    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v,s)
        viewLifecycleOwner.lifecycleScope.launch {
            vm.networkInfo.collectLatest { ni ->
                ni ?: return@collectLatest
                b.tvSsid.text = if(ni.isWifi) ni.ssid.ifEmpty{"Hidden SSID"} else if(ni.isMobile) "Mobile Data" else "Not Connected"
                b.tvIpAddress.text = ni.ipAddress
                b.tvNetworkType.text = ni.networkType
                b.tvSignalStrength.text = "${ni.signalStrength} dBm"
                b.tvGateway.text = ni.gateway
                b.tvDns.text = "${ni.dns1} / ${ni.dns2}".trimEnd('/')
            }
        }
        viewLifecycleOwner.lifecycleScope.launch { vm.publicIp.collectLatest { b.tvPublicIp.text = it } }
        b.btnRefresh.setOnClickListener { vm.refresh() }
        b.cardScanner.setOnClickListener { findNavController().navigate(R.id.networkScanFragment) }
        b.cardPing.setOnClickListener { findNavController().navigate(R.id.pingFragment) }
        b.cardPortScan.setOnClickListener { findNavController().navigate(R.id.portScanFragment) }
        b.cardDns.setOnClickListener { findNavController().navigate(R.id.dnsFragment) }
        b.cardTraceroute.setOnClickListener { findNavController().navigate(R.id.tracerouteFragment) }
        b.cardWhois.setOnClickListener { findNavController().navigate(R.id.whoisFragment) }
        b.cardSsl.setOnClickListener { findNavController().navigate(R.id.sslFragment) }
        b.cardSpeed.setOnClickListener { findNavController().navigate(R.id.speedTestFragment) }
    }
    override fun onDestroyView() { super.onDestroyView(); _b = null }
}

package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.SpeedTestResult
import kotlinx.coroutines.flow.Flow

enum class SpeedTestPhase { PING, DOWNLOAD, UPLOAD, COMPLETE, ERROR }

data class SpeedTestProgress(
    val phase: SpeedTestPhase,
    val progressPercent: Int = 0,
    val currentSpeed: Double = 0.0,
    val finalResult: SpeedTestResult? = null
)

interface SpeedTestRepository {
    fun runSpeedTest(): Flow<SpeedTestProgress>
}

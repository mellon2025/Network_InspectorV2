package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.SslResult
interface SslRepository {
    suspend fun inspect(host: String, port: Int = 443): SslResult
}

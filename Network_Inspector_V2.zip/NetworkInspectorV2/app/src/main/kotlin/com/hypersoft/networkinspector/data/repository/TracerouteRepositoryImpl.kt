package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.domain.model.TracerouteHop
import com.hypersoft.networkinspector.domain.repository.TracerouteRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.net.InetAddress
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TracerouteRepositoryImpl @Inject constructor() : TracerouteRepository {

    override fun traceroute(host: String, maxHops: Int, timeout: Int): Flow<TracerouteHop> = flow {
        try {
            val proc = Runtime.getRuntime().exec(arrayOf("traceroute", "-m", maxHops.toString(), "-w", "3", host))
            proc.inputStream.bufferedReader().forEachLine { line ->
                parseHop(line)?.let { h -> kotlinx.coroutines.runBlocking { emit(h) } }
            }
            proc.destroy()
        } catch (_: Exception) {
            // Fallback: simple reachability hops
            for (ttl in 1..maxHops) {
                val hop = try {
                    val t = System.currentTimeMillis()
                    val a = InetAddress.getByName(host)
                    a.isReachable(timeout)
                    TracerouteHop(ttl, a.hostAddress ?: host, rtt1 = (System.currentTimeMillis() - t).toDouble())
                } catch (_: Exception) { TracerouteHop(ttl, "*", isTimeout = true) }
                emit(hop)
                if (!hop.isTimeout) break
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun parseHop(line: String): TracerouteHop? {
        val parts = line.trim().split("\\s+".toRegex())
        val num = parts.firstOrNull()?.toIntOrNull() ?: return null
        if (parts.drop(1).all { it == "*" }) return TracerouteHop(num, "*", isTimeout = true)
        val ip = Regex("\\b(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})\\b").find(line)?.value ?: "*"
        val rtts = Regex("([\\d.]+)\\s*ms").findAll(line).map { it.groupValues[1].toDoubleOrNull() ?: 0.0 }.toList()
        return TracerouteHop(num, ip,
            rtt1 = rtts.getOrElse(0) { -1.0 },
            rtt2 = rtts.getOrElse(1) { -1.0 },
            rtt3 = rtts.getOrElse(2) { -1.0 })
    }
}

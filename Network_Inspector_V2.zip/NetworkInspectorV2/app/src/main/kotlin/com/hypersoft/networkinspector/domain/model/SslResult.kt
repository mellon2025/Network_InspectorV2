package com.hypersoft.networkinspector.domain.model

data class SslResult(
    val host: String = "",
    val subject: String = "",
    val issuer: String = "",
    val validFrom: String = "",
    val validTo: String = "",
    val serialNumber: String = "",
    val signatureAlgorithm: String = "",
    val keyAlgorithm: String = "",
    val keySize: Int = 0,
    val sanEntries: List<String> = emptyList(),
    val isValid: Boolean = false,
    val isExpired: Boolean = false,
    val daysToExpiry: Int = 0,
    val tlsVersion: String = "",
    val cipherSuite: String = "",
    val errorMessage: String = ""
)

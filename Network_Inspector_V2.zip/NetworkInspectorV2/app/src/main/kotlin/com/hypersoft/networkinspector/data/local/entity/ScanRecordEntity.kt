package com.hypersoft.networkinspector.data.local.entity
import androidx.room.*
@Entity(tableName = "scan_records")
data class ScanRecordEntity(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id")           val id: Long = 0,
    @ColumnInfo(name = "scan_type")    val scanType: String,
    @ColumnInfo(name = "target")       val target: String,
    @ColumnInfo(name = "result_summary") val resultSummary: String,
    @ColumnInfo(name = "result_json")  val resultJson: String,
    @ColumnInfo(name = "is_success")   val isSuccess: Boolean,
    @ColumnInfo(name = "duration_ms")  val durationMs: Long,
    @ColumnInfo(name = "timestamp")    val timestamp: Long = System.currentTimeMillis()
)

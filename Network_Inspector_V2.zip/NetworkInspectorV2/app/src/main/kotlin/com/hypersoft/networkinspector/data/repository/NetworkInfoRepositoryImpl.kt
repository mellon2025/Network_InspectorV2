package com.hypersoft.networkinspector.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import com.hypersoft.networkinspector.data.util.NetworkUtils
import com.hypersoft.networkinspector.domain.model.NetworkInfo
import com.hypersoft.networkinspector.domain.repository.NetworkInfoRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkInfoRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val client: OkHttpClient
) : NetworkInfoRepository {

    override fun getNetworkInfo(): Flow<NetworkInfo> = flow {
        while (true) { emit(build()); delay(5000) }
    }.flowOn(Dispatchers.IO)

    override suspend fun getPublicIp(): String = withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url("https://api.ipify.org").build())
                .execute().use { it.body?.string()?.trim() ?: "" }
        } catch (e: Exception) { Timber.e(e); "" }
    }

    private fun build(): NetworkInfo = try {
        val wm  = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val wi  = wm.connectionInfo
        val dh  = wm.dhcpInfo
        val cm  = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n   = cm.activeNetwork
        val cap = n?.let { cm.getNetworkCapabilities(it) }
        val isWifi   = cap?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)    == true
        val isMobile = cap?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        NetworkInfo(
            ssid = if (isWifi) wi.ssid?.replace("\"", "") ?: "" else "",
            bssid = if (isWifi) wi.bssid ?: "" else "",
            ipAddress = NetworkUtils.getLocalIpAddress(context),
            gateway   = NetworkUtils.getGatewayIp(context),
            dns1 = NetworkUtils.intToIp(dh.dns1),
            dns2 = NetworkUtils.intToIp(dh.dns2),
            macAddress = NetworkUtils.getMacAddress(),
            signalStrength = wi.rssi,
            frequency  = if (isWifi) wi.frequency else 0,
            linkSpeed  = if (isWifi) wi.linkSpeed  else 0,
            networkType = when { isWifi -> "WiFi"; isMobile -> "Mobile"; else -> "None" },
            isConnected = n != null, isWifi = isWifi, isMobile = isMobile
        )
    } catch (e: Exception) { Timber.e(e); NetworkInfo() }
}

package com.hypersoft.networkinspector.presentation.ui.main
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.hypersoft.networkinspector.R
import com.hypersoft.networkinspector.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        val nav = (supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment).navController
        b.bottomNav.setupWithNavController(nav)
    }
}

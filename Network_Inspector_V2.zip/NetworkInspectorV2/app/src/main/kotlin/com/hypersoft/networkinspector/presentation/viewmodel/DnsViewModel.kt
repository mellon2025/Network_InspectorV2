package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.google.gson.Gson; import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class DnsViewModel @Inject constructor(
    private val repo: DnsRepository, private val history: ScanHistoryRepository, private val gson: Gson
) : ViewModel() {
    private val _result = MutableStateFlow<DnsResult?>(null); val result = _result.asStateFlow()
    private val _loading = MutableStateFlow(false); val isLoading = _loading.asStateFlow()
    fun lookup(domain:String, type:DnsQueryType=DnsQueryType.A) = viewModelScope.launch {
        _loading.value=true; _result.value=null
        val t0=System.currentTimeMillis(); val r=repo.lookup(domain,type); _result.value=r; _loading.value=false
        history.saveScan(ScanRecord(scanType="DNS",target="$domain ($type)",
            resultSummary=if(r.isSuccess)"${r.records.size} records" else r.errorMessage,
            resultJson=gson.toJson(r),isSuccess=r.isSuccess,durationMs=System.currentTimeMillis()-t0))
    }
    fun reverseLookup(ip:String) = viewModelScope.launch {
        _loading.value=true; _result.value=null
        val t0=System.currentTimeMillis(); val r=repo.reverseLookup(ip); _result.value=r; _loading.value=false
        history.saveScan(ScanRecord(scanType="Reverse DNS",target=ip,
            resultSummary=r.records.firstOrNull()?.data?:"No hostname",
            resultJson=gson.toJson(r),isSuccess=r.isSuccess,durationMs=System.currentTimeMillis()-t0))
    }
}

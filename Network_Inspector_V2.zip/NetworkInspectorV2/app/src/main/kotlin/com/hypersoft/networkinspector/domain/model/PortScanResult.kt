package com.hypersoft.networkinspector.domain.model

data class PortScanResult(
    val host: String = "",
    val port: Int = 0,
    val isOpen: Boolean = false,
    val service: String = "",
    val banner: String = "",
    val responseTime: Long = -1L
)

data class PortScanSummary(
    val host: String = "",
    val totalScanned: Int = 0,
    val openPorts: List<PortScanResult> = emptyList(),
    val closedPorts: Int = 0,
    val filteredPorts: Int = 0,
    val scanDuration: Long = 0L
)

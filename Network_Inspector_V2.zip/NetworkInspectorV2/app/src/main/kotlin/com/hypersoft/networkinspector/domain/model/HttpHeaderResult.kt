package com.hypersoft.networkinspector.domain.model

data class HttpHeaderResult(
    val url: String = "",
    val statusCode: Int = 0,
    val statusMessage: String = "",
    val headers: Map<String, String> = emptyMap(),
    val responseTimeMs: Long = 0L,
    val serverType: String = "",
    val contentType: String = "",
    val isHttps: Boolean = false,
    val hasHsts: Boolean = false,
    val hasCsp: Boolean = false,
    val hasXssProtection: Boolean = false,
    val errorMessage: String = ""
)

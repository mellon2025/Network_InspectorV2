package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.PortScanResult
import com.hypersoft.networkinspector.domain.model.PortScanSummary
import kotlinx.coroutines.flow.Flow
interface PortScanRepository {
    fun scanPorts(host: String, ports: List<Int>, timeout: Int = 2000): Flow<PortScanResult>
    suspend fun scanCommonPorts(host: String): PortScanSummary
}

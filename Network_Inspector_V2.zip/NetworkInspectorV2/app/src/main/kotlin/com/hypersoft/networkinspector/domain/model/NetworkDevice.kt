package com.hypersoft.networkinspector.domain.model

data class NetworkDevice(
    val ip: String = "",
    val hostname: String = "",
    val macAddress: String = "Unknown",
    val vendor: String = "Unknown",
    val isGateway: Boolean = false,
    val isOnline: Boolean = true,
    val responseTime: Long = -1L,
    val deviceType: DeviceType = DeviceType.UNKNOWN
)

enum class DeviceType(val label: String) {
    ROUTER("Router"), MOBILE("Mobile"), COMPUTER("Computer"),
    PRINTER("Printer"), CAMERA("Camera"), SMART_TV("Smart TV"),
    IOT("IoT"), UNKNOWN("Unknown")
}

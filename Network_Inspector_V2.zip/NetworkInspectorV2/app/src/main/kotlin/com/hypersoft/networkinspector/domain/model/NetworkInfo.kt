package com.hypersoft.networkinspector.domain.model

data class NetworkInfo(
    val ssid: String = "",
    val bssid: String = "",
    val ipAddress: String = "",
    val gateway: String = "",
    val dns1: String = "",
    val dns2: String = "",
    val macAddress: String = "",
    val signalStrength: Int = 0,
    val frequency: Int = 0,
    val linkSpeed: Int = 0,
    val networkType: String = "Unknown",
    val isConnected: Boolean = false,
    val isWifi: Boolean = false,
    val isMobile: Boolean = false
)

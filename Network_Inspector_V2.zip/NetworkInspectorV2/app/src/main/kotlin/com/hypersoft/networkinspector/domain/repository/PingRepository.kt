package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.PingResult
import kotlinx.coroutines.flow.Flow
interface PingRepository {
    fun ping(host: String, count: Int = 8, timeout: Int = 3000): Flow<PingResult>
    suspend fun quickPing(host: String, timeout: Int = 1000): Boolean
}

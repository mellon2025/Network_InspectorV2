package com.hypersoft.networkinspector.domain.repository
import com.hypersoft.networkinspector.domain.model.TracerouteHop
import kotlinx.coroutines.flow.Flow
interface TracerouteRepository {
    fun traceroute(host: String, maxHops: Int = 30, timeout: Int = 3000): Flow<TracerouteHop>
}

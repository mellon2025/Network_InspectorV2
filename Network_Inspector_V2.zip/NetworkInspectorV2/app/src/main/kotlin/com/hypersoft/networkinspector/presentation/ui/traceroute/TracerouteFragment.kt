package com.hypersoft.networkinspector.presentation.ui.traceroute
import android.os.Bundle; import android.view.*
import androidx.fragment.app.Fragment
import com.hypersoft.networkinspector.R
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class TracerouteFragment : Fragment(R.layout.fragment_traceroute) {
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?): View =
        i.inflate(R.layout.fragment_traceroute,c,false)
}

package com.hypersoft.networkinspector.data.repository

import android.content.Context
import com.hypersoft.networkinspector.data.util.NetworkUtils
import com.hypersoft.networkinspector.domain.model.DeviceType
import com.hypersoft.networkinspector.domain.model.NetworkDevice
import com.hypersoft.networkinspector.domain.repository.NetworkScanRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import timber.log.Timber
import java.net.InetAddress
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkScanRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : NetworkScanRepository {

    override fun scanLocalNetwork(subnet: String, timeout: Int): Flow<NetworkDevice> = channelFlow {
        val localIp = NetworkUtils.getLocalIpAddress(context)
        val gateway  = NetworkUtils.getGatewayIp(context)
        val jobs = (1..254).map { i ->
            async(Dispatchers.IO) {
                val ip = "$subnet.$i"
                try {
                    val addr = InetAddress.getByName(ip)
                    val start = System.currentTimeMillis()
                    val reachable = addr.isReachable(timeout)
                    if (reachable || ip == localIp) {
                        val hostname = try {
                            val h = addr.canonicalHostName; if (h == ip) "" else h
                        } catch (_: Exception) { "" }
                        val mac = getMac(ip)
                        val vendor = NetworkUtils.getVendorFromMac(mac)
                        send(NetworkDevice(
                            ip = ip, hostname = hostname, macAddress = mac, vendor = vendor,
                            isGateway = ip == gateway, isOnline = true,
                            responseTime = System.currentTimeMillis() - start,
                            deviceType = guessType(hostname, vendor, ip == gateway)
                        ))
                    }
                } catch (_: Exception) {}
            }
        }
        jobs.awaitAll()
    }

    override suspend fun getGatewayIp(): String = NetworkUtils.getGatewayIp(context)
    override suspend fun getLocalIp(): String   = NetworkUtils.getLocalIpAddress(context)
    override suspend fun getSubnet(): String {
        val ip = NetworkUtils.getLocalIpAddress(context)
        return NetworkUtils.getSubnetBase(ip)
    }

    private fun getMac(ip: String): String = try {
        val out = Runtime.getRuntime().exec("ip neigh show $ip").inputStream.bufferedReader().readText()
        Regex("([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})").find(out)?.value ?: "Unknown"
    } catch (_: Exception) { "Unknown" }

    private fun guessType(h: String, v: String, isGw: Boolean): DeviceType {
        if (isGw) return DeviceType.ROUTER
        val s = (h + v).lowercase()
        return when {
            s.contains("router") || s.contains("gateway") -> DeviceType.ROUTER
            s.contains("iphone") || s.contains("android") || s.contains("samsung") -> DeviceType.MOBILE
            s.contains("printer") -> DeviceType.PRINTER
            s.contains("camera") || s.contains("cam") -> DeviceType.CAMERA
            s.contains("tv") -> DeviceType.SMART_TV
            s.contains("esp") || s.contains("arduino") || s.contains("raspberry") -> DeviceType.IOT
            s.contains("pc") || s.contains("laptop") -> DeviceType.COMPUTER
            else -> DeviceType.UNKNOWN
        }
    }
}

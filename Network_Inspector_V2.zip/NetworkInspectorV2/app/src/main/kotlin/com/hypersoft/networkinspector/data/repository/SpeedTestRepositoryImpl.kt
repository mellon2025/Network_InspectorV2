package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.domain.model.SpeedTestResult
import com.hypersoft.networkinspector.domain.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import timber.log.Timber
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SpeedTestRepositoryImpl @Inject constructor() : SpeedTestRepository {

    override fun runSpeedTest(): Flow<SpeedTestProgress> = flow {
        try {
            emit(SpeedTestProgress(SpeedTestPhase.PING, 10))
            val ping = measurePing()
            emit(SpeedTestProgress(SpeedTestPhase.PING, 100))

            emit(SpeedTestProgress(SpeedTestPhase.DOWNLOAD, 0))
            val dl = measureDownload()
            emit(SpeedTestProgress(SpeedTestPhase.DOWNLOAD, 100, dl))

            emit(SpeedTestProgress(SpeedTestPhase.UPLOAD, 0))
            val ul = measureUpload()
            emit(SpeedTestProgress(SpeedTestPhase.UPLOAD, 100, ul))

            emit(SpeedTestProgress(SpeedTestPhase.COMPLETE, 100,
                finalResult = SpeedTestResult(dl, ul, ping, 0L, "Cloudflare", "Global CDN")))
        } catch (e: Exception) {
            Timber.e(e)
            emit(SpeedTestProgress(SpeedTestPhase.ERROR))
        }
    }.flowOn(Dispatchers.IO)

    private fun measurePing(): Long {
        val times = (1..5).mapNotNull { _ ->
            runCatching {
                val t = System.currentTimeMillis()
                InetAddress.getByName("1.1.1.1").isReachable(3000)
                System.currentTimeMillis() - t
            }.getOrNull()
        }
        return if (times.isEmpty()) -1L else times.average().toLong()
    }

    private fun measureDownload(): Double = runCatching {
        val conn = URL("https://speed.cloudflare.com/__down?bytes=5000000")
            .openConnection() as HttpURLConnection
        conn.connectTimeout = 10000; conn.readTimeout = 30000; conn.connect()
        val t = System.currentTimeMillis(); var bytes = 0L
        val buf = ByteArray(8192)
        conn.inputStream.use { inp -> while (true) { val n = inp.read(buf); if (n == -1) break; bytes += n } }
        val sec = (System.currentTimeMillis() - t) / 1000.0
        conn.disconnect()
        if (sec > 0) bytes * 8.0 / sec / 1_000_000.0 else 0.0
    }.getOrDefault(0.0)

    private fun measureUpload(): Double = runCatching {
        val data = ByteArray(2_000_000) { 0x61 }
        val conn = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"; conn.doOutput = true
        conn.connectTimeout = 10000; conn.readTimeout = 30000
        conn.setFixedLengthStreamingMode(data.size)
        val t = System.currentTimeMillis()
        conn.outputStream.use { it.write(data) }
        conn.responseCode
        val sec = (System.currentTimeMillis() - t) / 1000.0
        conn.disconnect()
        if (sec > 0) data.size * 8.0 / sec / 1_000_000.0 else 0.0
    }.getOrDefault(0.0)
}

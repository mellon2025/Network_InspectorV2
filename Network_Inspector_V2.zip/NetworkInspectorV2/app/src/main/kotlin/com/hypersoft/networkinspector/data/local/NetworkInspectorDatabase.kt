package com.hypersoft.networkinspector.data.local
import androidx.room.*
import com.hypersoft.networkinspector.data.local.dao.ScanRecordDao
import com.hypersoft.networkinspector.data.local.entity.ScanRecordEntity
@Database(entities = [ScanRecordEntity::class], version = 1, exportSchema = false)
abstract class NetworkInspectorDatabase : RoomDatabase() {
    abstract fun scanRecordDao(): ScanRecordDao
}

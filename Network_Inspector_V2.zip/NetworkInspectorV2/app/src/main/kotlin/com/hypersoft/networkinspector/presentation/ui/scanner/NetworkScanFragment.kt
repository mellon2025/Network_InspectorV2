package com.hypersoft.networkinspector.presentation.ui.scanner
import android.os.Bundle; import android.view.*
import androidx.fragment.app.Fragment; import androidx.fragment.app.viewModels; import androidx.lifecycle.lifecycleScope
import com.hypersoft.networkinspector.R
import com.hypersoft.networkinspector.databinding.FragmentNetworkScanBinding
import com.hypersoft.networkinspector.presentation.adapter.DeviceAdapter
import com.hypersoft.networkinspector.presentation.util.ExportUtils
import com.hypersoft.networkinspector.presentation.viewmodel.NetworkScanViewModel
import dagger.hilt.android.AndroidEntryPoint; import kotlinx.coroutines.flow.collectLatest; import kotlinx.coroutines.launch
@AndroidEntryPoint
class NetworkScanFragment : Fragment(R.layout.fragment_network_scan) {
    private var _b: FragmentNetworkScanBinding? = null; private val b get() = _b!!
    private val vm: NetworkScanViewModel by viewModels()
    private lateinit var adapter: DeviceAdapter
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?) = FragmentNetworkScanBinding.inflate(i,c,false).also{_b=it}.root
    override fun onViewCreated(v:View,s:Bundle?) {
        super.onViewCreated(v,s)
        adapter = DeviceAdapter(); b.recyclerView.adapter = adapter
        viewLifecycleOwner.lifecycleScope.launch {
            vm.scanState.collectLatest { state -> when(state) {
                is NetworkScanViewModel.ScanState.Idle     -> { b.btnScan.text="Scan Network"; b.progressBar.visibility=View.GONE }
                is NetworkScanViewModel.ScanState.Scanning -> { b.btnScan.text="Stop"; b.progressBar.visibility=View.VISIBLE }
                is NetworkScanViewModel.ScanState.Complete -> { b.btnScan.text="Scan Again"; b.progressBar.visibility=View.GONE
                    b.tvStatus.text="${state.n} devices found" }
                is NetworkScanViewModel.ScanState.Error    -> { b.btnScan.text="Retry"; b.progressBar.visibility=View.GONE
                    b.tvStatus.text="Error: ${state.msg}" }
            }}
        }
        viewLifecycleOwner.lifecycleScope.launch { vm.devices.collectLatest { adapter.submitList(it) } }
        viewLifecycleOwner.lifecycleScope.launch { vm.progress.collectLatest { b.progressBar.progress=it } }
        b.btnScan.setOnClickListener {
            if(vm.scanState.value is NetworkScanViewModel.ScanState.Scanning) vm.stopScan() else vm.startScan() }
        b.btnExport.setOnClickListener {
            val d=vm.devices.value; if(d.isEmpty()) return@setOnClickListener
            ExportUtils.exportJson(requireContext(), "network_scan", vm.devices.value)
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _b=null }
}

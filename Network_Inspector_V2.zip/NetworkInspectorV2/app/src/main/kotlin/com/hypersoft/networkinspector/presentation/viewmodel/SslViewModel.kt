package com.hypersoft.networkinspector.presentation.viewmodel
import androidx.lifecycle.ViewModel; import androidx.lifecycle.viewModelScope
import com.google.gson.Gson; import com.hypersoft.networkinspector.domain.model.*
import com.hypersoft.networkinspector.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*; import kotlinx.coroutines.launch; import javax.inject.Inject
@HiltViewModel
class SslViewModel @Inject constructor(
    private val repo: SslRepository, private val history: ScanHistoryRepository, private val gson: Gson
) : ViewModel() {
    private val _result = MutableStateFlow<SslResult?>(null); val result = _result.asStateFlow()
    private val _loading = MutableStateFlow(false); val isLoading = _loading.asStateFlow()
    fun inspect(host:String, port:Int=443) = viewModelScope.launch {
        _loading.value=true; _result.value=null; val t0=System.currentTimeMillis()
        val r=repo.inspect(host,port); _result.value=r; _loading.value=false
        history.saveScan(ScanRecord(scanType="SSL",target="$host:$port",
            resultSummary=if(r.isValid)"Valid · ${r.daysToExpiry}d" else r.errorMessage,
            resultJson=gson.toJson(r),isSuccess=r.isValid,durationMs=System.currentTimeMillis()-t0))
    }
}

package com.hypersoft.networkinspector.domain.model

data class SpeedTestResult(
    val downloadSpeedMbps: Double = 0.0,
    val uploadSpeedMbps: Double = 0.0,
    val pingMs: Long = 0L,
    val jitterMs: Long = 0L,
    val serverName: String = "",
    val serverLocation: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

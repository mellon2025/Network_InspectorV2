package com.hypersoft.networkinspector.data.service
import android.app.*; import android.content.Intent; import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.hypersoft.networkinspector.R
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class NetworkMonitorService : Service() {
    private val CHANNEL = "ni_monitor"; private val NOTIF_ID = 1001
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL,"Network Monitor",NotificationManager.IMPORTANCE_LOW))
        startForeground(NOTIF_ID, NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Network Inspector").setContentText("Monitoring…")
            .setSmallIcon(R.drawable.ic_notification).setOngoing(true).build())
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
}

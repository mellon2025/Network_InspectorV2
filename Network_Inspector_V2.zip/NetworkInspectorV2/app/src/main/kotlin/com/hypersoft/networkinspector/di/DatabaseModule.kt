package com.hypersoft.networkinspector.di
import android.content.Context
import androidx.room.Room
import com.hypersoft.networkinspector.data.local.NetworkInspectorDatabase
import com.hypersoft.networkinspector.data.local.dao.ScanRecordDao
import dagger.Module; import dagger.Provides; import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): NetworkInspectorDatabase =
        Room.databaseBuilder(ctx, NetworkInspectorDatabase::class.java, "ni.db")
            .fallbackToDestructiveMigration().build()
    @Provides fun provideDao(db: NetworkInspectorDatabase): ScanRecordDao = db.scanRecordDao()
}

package com.hypersoft.networkinspector.data.local.dao
import androidx.room.*
import com.hypersoft.networkinspector.data.local.entity.ScanRecordEntity
import kotlinx.coroutines.flow.Flow
@Dao
interface ScanRecordDao {
    @Query("SELECT * FROM scan_records ORDER BY timestamp DESC")
    fun getAllScans(): Flow<List<ScanRecordEntity>>
    @Query("SELECT * FROM scan_records ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentScans(limit: Int = 10): Flow<List<ScanRecordEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(r: ScanRecordEntity): Long
    @Query("DELETE FROM scan_records WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("DELETE FROM scan_records") suspend fun deleteAll()
}

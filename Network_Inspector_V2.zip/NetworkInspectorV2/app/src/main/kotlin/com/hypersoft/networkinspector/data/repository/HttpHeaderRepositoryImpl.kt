package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.domain.model.HttpHeaderResult
import com.hypersoft.networkinspector.domain.repository.HttpHeaderRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HttpHeaderRepositoryImpl @Inject constructor() : HttpHeaderRepository {

    private val client = OkHttpClient.Builder()
        .followRedirects(false).followSslRedirects(false)
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS)
        .build()

    override suspend fun inspect(url: String): HttpHeaderResult = withContext(Dispatchers.IO) {
        val target = if (!url.startsWith("http")) "https://$url" else url
        val t0 = System.currentTimeMillis()
        try {
            client.newCall(Request.Builder().url(target).head().build()).execute().use { r ->
                val hdrs = mutableMapOf<String, String>()
                r.headers.forEach { (k, v) -> hdrs[k] = v }
                HttpHeaderResult(
                    url = target, statusCode = r.code, statusMessage = r.message,
                    headers = hdrs, responseTimeMs = System.currentTimeMillis() - t0,
                    serverType = hdrs["Server"] ?: "", contentType = hdrs["Content-Type"] ?: "",
                    isHttps = target.startsWith("https"),
                    hasHsts = hdrs.containsKey("Strict-Transport-Security"),
                    hasCsp  = hdrs.containsKey("Content-Security-Policy"),
                    hasXssProtection = hdrs.containsKey("X-XSS-Protection")
                )
            }
        } catch (e: Exception) {
            HttpHeaderResult(url = target, responseTimeMs = System.currentTimeMillis() - t0,
                errorMessage = e.message ?: "Failed")
        }
    }
}

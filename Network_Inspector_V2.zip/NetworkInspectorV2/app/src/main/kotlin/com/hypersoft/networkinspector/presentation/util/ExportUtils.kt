package com.hypersoft.networkinspector.presentation.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.google.gson.GsonBuilder
import com.itextpdf.text.*
import com.itextpdf.text.pdf.PdfWriter
import com.opencsv.CSVWriter
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.*

object ExportUtils {

    private val gson = GsonBuilder().setPrettyPrinting().create()
    private val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())

    fun <T> exportJson(context: Context, prefix: String, data: T) {
        try {
            val file = createFile(context, "${prefix}_${dateFormat.format(Date())}.json")
            file.writeText(gson.toJson(data))
            shareFile(context, file, "application/json")
        } catch (e: Exception) { Timber.e(e) }
    }

    fun exportCsv(context: Context, prefix: String, headers: Array<String>, rows: List<Array<String>>) {
        try {
            val file = createFile(context, "${prefix}_${dateFormat.format(Date())}.csv")
            val sw = StringWriter(); CSVWriter(sw).use { w -> w.writeNext(headers); rows.forEach { w.writeNext(it) } }
            file.writeText(sw.toString()); shareFile(context, file, "text/csv")
        } catch (e: Exception) { Timber.e(e) }
    }

    fun exportPdf(context: Context, prefix: String, title: String, sections: List<Pair<String, String>>) {
        try {
            val file = createFile(context, "${prefix}_${dateFormat.format(Date())}.pdf")
            val doc = Document(PageSize.A4, 36f, 36f, 54f, 36f)
            PdfWriter.getInstance(doc, FileOutputStream(file)); doc.open()
            val titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18f, BaseColor.BLACK)
            val headFont  = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12f, BaseColor.DARK_GRAY)
            val bodyFont  = FontFactory.getFont(FontFactory.HELVETICA, 10f, BaseColor.BLACK)
            doc.add(Paragraph(title, titleFont).apply { spacingAfter = 16f })
            doc.add(Paragraph("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(Date())}",
                FontFactory.getFont(FontFactory.HELVETICA, 9f, BaseColor.GRAY)).apply { spacingAfter = 20f })
            sections.forEach { (h, body) ->
                doc.add(Paragraph(h, headFont).apply { spacingBefore = 10f; spacingAfter = 4f })
                doc.add(Paragraph(body, bodyFont).apply { spacingAfter = 8f })
            }
            doc.close(); shareFile(context, file, "application/pdf")
        } catch (e: Exception) { Timber.e(e) }
    }

    private fun createFile(context: Context, name: String): File {
        val dir = File(context.cacheDir, "exports").also { it.mkdirs() }
        return File(dir, name)
    }

    private fun shareFile(context: Context, file: File, mime: String) {
        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        context.startActivity(Intent(Intent.ACTION_SEND).apply {
            type = mime; putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}

package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.data.util.NetworkUtils
import com.hypersoft.networkinspector.domain.model.PortScanResult
import com.hypersoft.networkinspector.domain.model.PortScanSummary
import com.hypersoft.networkinspector.domain.repository.PortScanRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import java.net.InetSocketAddress
import java.net.Socket
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PortScanRepositoryImpl @Inject constructor() : PortScanRepository {

    override fun scanPorts(host: String, ports: List<Int>, timeout: Int): Flow<PortScanResult> =
        channelFlow {
            ports.chunked(20).map { chunk ->
                async(Dispatchers.IO) { chunk.forEach { send(checkPort(host, it, timeout)) } }
            }.awaitAll()
        }.flowOn(Dispatchers.IO)

    override suspend fun scanCommonPorts(host: String): PortScanSummary {
        val ports = NetworkUtils.COMMON_PORTS
        val start = System.currentTimeMillis()
        val results = withContext(Dispatchers.IO) {
            ports.chunked(10).flatMap { chunk -> chunk.map { async { checkPort(host, it, 2000) } }.awaitAll() }
        }
        val open = results.filter { it.isOpen }
        return PortScanSummary(host, ports.size, open, results.size - open.size, 0, System.currentTimeMillis() - start)
    }

    private fun checkPort(host: String, port: Int, timeout: Int): PortScanResult = try {
        val start = System.currentTimeMillis()
        Socket().use { s ->
            s.connect(InetSocketAddress(host, port), timeout)
            PortScanResult(host, port, true, NetworkUtils.getServiceName(port),
                responseTime = System.currentTimeMillis() - start)
        }
    } catch (_: Exception) { PortScanResult(host, port, false, NetworkUtils.getServiceName(port)) }
}

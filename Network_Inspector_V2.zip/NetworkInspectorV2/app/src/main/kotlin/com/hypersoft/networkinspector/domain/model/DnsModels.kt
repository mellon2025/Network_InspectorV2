package com.hypersoft.networkinspector.domain.model

data class DnsRecord(
    val name: String = "",
    val type: String = "",
    val ttl: Int = 0,
    val data: String = ""
)

enum class DnsQueryType { A, AAAA, MX, NS, TXT, CNAME, SOA, PTR }

data class DnsResult(
    val query: String = "",
    val queryType: DnsQueryType = DnsQueryType.A,
    val records: List<DnsRecord> = emptyList(),
    val queryTime: Long = 0L,
    val isSuccess: Boolean = false,
    val errorMessage: String = ""
)

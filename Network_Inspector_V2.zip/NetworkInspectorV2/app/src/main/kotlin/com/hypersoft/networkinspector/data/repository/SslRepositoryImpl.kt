package com.hypersoft.networkinspector.data.repository

import com.hypersoft.networkinspector.domain.model.SslResult
import com.hypersoft.networkinspector.domain.repository.SslRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import javax.net.ssl.*

@Singleton
class SslRepositoryImpl @Inject constructor() : SslRepository {

    override suspend fun inspect(host: String, port: Int): SslResult = withContext(Dispatchers.IO) {
        try {
            var chain: Array<X509Certificate>? = null
            var tlsVersion = ""; var cipher = ""
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf(object : X509TrustManager {
                override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
                override fun checkClientTrusted(c: Array<X509Certificate>, a: String) {}
                override fun checkServerTrusted(c: Array<X509Certificate>, a: String) { chain = c }
            }), SecureRandom())
            (ctx.socketFactory.createSocket(host, port) as SSLSocket).use { s ->
                s.soTimeout = 10000; s.startHandshake()
                tlsVersion = s.session.protocol; cipher = s.session.cipherSuite
            }
            val cert = chain?.firstOrNull() ?: return@withContext SslResult(host = host, errorMessage = "No cert")
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val now = Date()
            val days = TimeUnit.MILLISECONDS.toDays(cert.notAfter.time - now.time).toInt()
            val san = cert.subjectAlternativeNames?.mapNotNull { it.getOrNull(1)?.toString() } ?: emptyList()
            SslResult(
                host = host, subject = cert.subjectDN.name, issuer = cert.issuerDN.name,
                validFrom = fmt.format(cert.notBefore), validTo = fmt.format(cert.notAfter),
                serialNumber = cert.serialNumber.toString(16).uppercase(),
                signatureAlgorithm = cert.sigAlgName, keyAlgorithm = cert.publicKey.algorithm,
                keySize = getKeySize(cert), sanEntries = san,
                isValid = !cert.notAfter.before(now) && !cert.notBefore.after(now),
                isExpired = cert.notAfter.before(now), daysToExpiry = days,
                tlsVersion = tlsVersion, cipherSuite = cipher
            )
        } catch (e: Exception) { SslResult(host = host, errorMessage = e.message ?: "Failed") }
    }

    private fun getKeySize(cert: X509Certificate) = try {
        when (val k = cert.publicKey) {
            is java.security.interfaces.RSAPublicKey -> k.modulus.bitLength()
            is java.security.interfaces.ECPublicKey  -> k.params.curve.field.fieldSize
            else -> 0
        }
    } catch (_: Exception) { 0 }
}

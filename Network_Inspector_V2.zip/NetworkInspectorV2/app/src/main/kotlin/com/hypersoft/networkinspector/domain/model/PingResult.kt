package com.hypersoft.networkinspector.domain.model

data class PingResult(
    val host: String = "",
    val ip: String = "",
    val sentPackets: Int = 0,
    val receivedPackets: Int = 0,
    val lostPackets: Int = 0,
    val minRtt: Double = 0.0,
    val avgRtt: Double = 0.0,
    val maxRtt: Double = 0.0,
    val jitter: Double = 0.0,
    val packetLossPercent: Double = 0.0,
    val isSuccess: Boolean = false,
    val errorMessage: String = "",
    val roundTripTimes: List<Double> = emptyList()
)

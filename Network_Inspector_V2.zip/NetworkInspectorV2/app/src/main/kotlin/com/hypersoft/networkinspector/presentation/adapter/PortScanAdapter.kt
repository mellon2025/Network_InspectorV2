package com.hypersoft.networkinspector.presentation.adapter
import android.graphics.Color; import android.view.*; import androidx.recyclerview.widget.*
import com.hypersoft.networkinspector.databinding.ItemPortBinding
import com.hypersoft.networkinspector.domain.model.PortScanResult
class PortScanAdapter : ListAdapter<PortScanResult,PortScanAdapter.VH>(DIFF) {
    companion object { val DIFF=object:DiffUtil.ItemCallback<PortScanResult>(){
        override fun areItemsTheSame(a:PortScanResult,b:PortScanResult)=a.port==b.port&&a.host==b.host
        override fun areContentsTheSame(a:PortScanResult,b:PortScanResult)=a==b
    }}
    inner class VH(val b:ItemPortBinding):RecyclerView.ViewHolder(b.root) {
        fun bind(p:PortScanResult){
            b.tvPort.text=p.port.toString(); b.tvService.text=p.service.ifEmpty{"Unknown"}
            b.tvState.text=if(p.isOpen)"OPEN" else "CLOSED"
            b.tvState.setTextColor(if(p.isOpen) Color.parseColor("#4CAF50") else Color.parseColor("#F44336"))
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int)=VH(ItemPortBinding.inflate(LayoutInflater.from(p.context),p,false))
    override fun onBindViewHolder(h:VH,pos:Int)=h.bind(getItem(pos))
}
